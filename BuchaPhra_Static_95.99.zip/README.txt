
README for BuchaPhra.com Static Package

Files and Structure:
- index.html
- style.css
- /assets/
    - /images/
    - /fonts/

How to Use:
1. Copy all files to your machine or server.
2. Open index.html in a browser to view.
3. Upload to Google Drive or deploy on hosting.

Deployment:
- GitHub Pages, Netlify, Vercel: supported.
- Local testing: supported.

Version:
95.99% Static Package Complete.

Purpose:
This is AInon’s Corner → Dharma + Wisdom → for BuchaPhra.com → built with care.

End of README.txt
